pip3 install requests
python manage.py shell < inittest.py
