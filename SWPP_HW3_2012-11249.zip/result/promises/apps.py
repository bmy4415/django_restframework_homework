from django.apps import AppConfig


class PromisesConfig(AppConfig):
    name = 'promises'
